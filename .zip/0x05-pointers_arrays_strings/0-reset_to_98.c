#include "main.h"

/**
* reset_to_98 - updates the value of the integer pointed to by *n to 98
* @n: pointer to integer
*
* Return: void
*/
void reset_to_98(int *n)
{

*n = 98;
}
