THis project contains set of functions 
regarding to pointers and arrays
learn more about pointers and arrays